﻿
namespace kutuphane
{
    partial class anamenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(anamenu));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.kitapKartEkleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kitapGuncelleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kitapKartSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.okurKayıtEkleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.okurKayıtEkleToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.okurKayıtSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kitapAramaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oduncKitapKayıtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oduncKitapEkleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oduncKitapGuncelleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oduncKitapEkleToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.formToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Azure;
            this.menuStrip1.Font = new System.Drawing.Font("Tahoma", 17F);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.okurKayıtEkleToolStripMenuItem,
            this.kitapAramaToolStripMenuItem,
            this.oduncKitapKayıtToolStripMenuItem,
            this.formToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(962, 36);
            this.menuStrip1.TabIndex = 20;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kitapKartEkleToolStripMenuItem,
            this.kitapGuncelleToolStripMenuItem,
            this.kitapKartSilToolStripMenuItem});
            this.toolStripMenuItem1.Font = new System.Drawing.Font("Tahoma", 16F);
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(210, 32);
            this.toolStripMenuItem1.Text = "Kitap Kart İşlemleri";
            // 
            // kitapKartEkleToolStripMenuItem
            // 
            this.kitapKartEkleToolStripMenuItem.Name = "kitapKartEkleToolStripMenuItem";
            this.kitapKartEkleToolStripMenuItem.Size = new System.Drawing.Size(270, 32);
            this.kitapKartEkleToolStripMenuItem.Text = "Kitap Kart Ekle";
            this.kitapKartEkleToolStripMenuItem.Click += new System.EventHandler(this.kitapKartEkleToolStripMenuItem_Click);
            // 
            // kitapGuncelleToolStripMenuItem
            // 
            this.kitapGuncelleToolStripMenuItem.Name = "kitapGuncelleToolStripMenuItem";
            this.kitapGuncelleToolStripMenuItem.Size = new System.Drawing.Size(270, 32);
            this.kitapGuncelleToolStripMenuItem.Text = "Kitap Kart Guncelle";
            this.kitapGuncelleToolStripMenuItem.Click += new System.EventHandler(this.kitapGuncelleToolStripMenuItem_Click);
            // 
            // kitapKartSilToolStripMenuItem
            // 
            this.kitapKartSilToolStripMenuItem.Name = "kitapKartSilToolStripMenuItem";
            this.kitapKartSilToolStripMenuItem.Size = new System.Drawing.Size(270, 32);
            this.kitapKartSilToolStripMenuItem.Text = "Kitap Kart Sil";
            this.kitapKartSilToolStripMenuItem.Click += new System.EventHandler(this.kitapKartSilToolStripMenuItem_Click);
            // 
            // okurKayıtEkleToolStripMenuItem
            // 
            this.okurKayıtEkleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.okurKayıtEkleToolStripMenuItem1,
            this.okurKayıtSilToolStripMenuItem});
            this.okurKayıtEkleToolStripMenuItem.Name = "okurKayıtEkleToolStripMenuItem";
            this.okurKayıtEkleToolStripMenuItem.Size = new System.Drawing.Size(164, 32);
            this.okurKayıtEkleToolStripMenuItem.Text = "Okur İşlemleri";
            // 
            // okurKayıtEkleToolStripMenuItem1
            // 
            this.okurKayıtEkleToolStripMenuItem1.Name = "okurKayıtEkleToolStripMenuItem1";
            this.okurKayıtEkleToolStripMenuItem1.Size = new System.Drawing.Size(237, 32);
            this.okurKayıtEkleToolStripMenuItem1.Text = "Okur Kayıt Ekle";
            this.okurKayıtEkleToolStripMenuItem1.Click += new System.EventHandler(this.okurKayıtEkleToolStripMenuItem1_Click);
            // 
            // okurKayıtSilToolStripMenuItem
            // 
            this.okurKayıtSilToolStripMenuItem.Name = "okurKayıtSilToolStripMenuItem";
            this.okurKayıtSilToolStripMenuItem.Size = new System.Drawing.Size(237, 32);
            this.okurKayıtSilToolStripMenuItem.Text = "Okur Kayıt Sil";
            this.okurKayıtSilToolStripMenuItem.Click += new System.EventHandler(this.okurKayıtSilToolStripMenuItem_Click);
            // 
            // kitapAramaToolStripMenuItem
            // 
            this.kitapAramaToolStripMenuItem.Name = "kitapAramaToolStripMenuItem";
            this.kitapAramaToolStripMenuItem.Size = new System.Drawing.Size(148, 32);
            this.kitapAramaToolStripMenuItem.Text = "Kitap Arama";
            this.kitapAramaToolStripMenuItem.Click += new System.EventHandler(this.kitapAramaToolStripMenuItem_Click);
            // 
            // oduncKitapKayıtToolStripMenuItem
            // 
            this.oduncKitapKayıtToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oduncKitapEkleToolStripMenuItem,
            this.oduncKitapGuncelleToolStripMenuItem,
            this.oduncKitapEkleToolStripMenuItem1});
            this.oduncKitapKayıtToolStripMenuItem.Name = "oduncKitapKayıtToolStripMenuItem";
            this.oduncKitapKayıtToolStripMenuItem.Size = new System.Drawing.Size(241, 32);
            this.oduncKitapKayıtToolStripMenuItem.Text = "Odunc Kitap İşlemleri";
            // 
            // oduncKitapEkleToolStripMenuItem
            // 
            this.oduncKitapEkleToolStripMenuItem.Name = "oduncKitapEkleToolStripMenuItem";
            this.oduncKitapEkleToolStripMenuItem.Size = new System.Drawing.Size(270, 32);
            this.oduncKitapEkleToolStripMenuItem.Text = "Odunc Kitap Kayıt";
            this.oduncKitapEkleToolStripMenuItem.Click += new System.EventHandler(this.oduncKitapEkleToolStripMenuItem_Click);
            // 
            // oduncKitapGuncelleToolStripMenuItem
            // 
            this.oduncKitapGuncelleToolStripMenuItem.Name = "oduncKitapGuncelleToolStripMenuItem";
            this.oduncKitapGuncelleToolStripMenuItem.Size = new System.Drawing.Size(270, 32);
            this.oduncKitapGuncelleToolStripMenuItem.Text = "Odunc Kitap Takip";
            this.oduncKitapGuncelleToolStripMenuItem.Click += new System.EventHandler(this.oduncKitapGuncelleToolStripMenuItem_Click);
            // 
            // oduncKitapEkleToolStripMenuItem1
            // 
            this.oduncKitapEkleToolStripMenuItem1.Name = "oduncKitapEkleToolStripMenuItem1";
            this.oduncKitapEkleToolStripMenuItem1.Size = new System.Drawing.Size(270, 32);
            this.oduncKitapEkleToolStripMenuItem1.Text = "Odunc Kitap Sil";
            this.oduncKitapEkleToolStripMenuItem1.Click += new System.EventHandler(this.oduncKitapEkleToolStripMenuItem1_Click);
            // 
            // formToolStripMenuItem
            // 
            this.formToolStripMenuItem.Name = "formToolStripMenuItem";
            this.formToolStripMenuItem.Size = new System.Drawing.Size(130, 32);
            this.formToolStripMenuItem.Text = "Borç Takip";
            this.formToolStripMenuItem.Click += new System.EventHandler(this.formToolStripMenuItem_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(119, 267);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(742, 262);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 21;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(330, 96);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 31);
            this.label1.TabIndex = 22;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(374, 154);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 31);
            this.label2.TabIndex = 23;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.button1.Location = new System.Drawing.Point(816, 49);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 33);
            this.button1.TabIndex = 24;
            this.button1.Text = "ZedGraph";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // anamenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(962, 573);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "anamenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "anamenu";
            this.Load += new System.EventHandler(this.anamenu_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem kitapKartEkleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kitapGuncelleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kitapKartSilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem okurKayıtEkleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem okurKayıtEkleToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem okurKayıtSilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kitapAramaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oduncKitapKayıtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oduncKitapEkleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oduncKitapGuncelleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oduncKitapEkleToolStripMenuItem1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.ToolStripMenuItem formToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
    }
}